/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_229()
{
    return 3347646675U;
}

unsigned getval_292()
{
    return 2425379010U;
}

unsigned addval_357(unsigned x)
{
    return x + 3347663049U;
}

void setval_131(unsigned *p)
{
    *p = 3284631880U;
}

unsigned getval_272()
{
    return 607043928U;
}

unsigned addval_162(unsigned x)
{
    return x + 3281025103U;
}

unsigned getval_186()
{
    return 3284633928U;
}

unsigned getval_387()
{
    return 2425393240U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_145(unsigned x)
{
    return x + 3372799497U;
}

unsigned addval_242(unsigned x)
{
    return x + 3284240725U;
}

unsigned addval_419(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_477(unsigned x)
{
    return x + 2425408137U;
}

unsigned getval_282()
{
    return 2428619261U;
}

unsigned addval_190(unsigned x)
{
    return x + 230938265U;
}

unsigned addval_255(unsigned x)
{
    return x + 3372796425U;
}

unsigned getval_313()
{
    return 3888368267U;
}

unsigned getval_336()
{
    return 2430634824U;
}

unsigned getval_289()
{
    return 3525891721U;
}

unsigned getval_210()
{
    return 3348152713U;
}

void setval_258(unsigned *p)
{
    *p = 3674789512U;
}

unsigned addval_176(unsigned x)
{
    return x + 3222850185U;
}

unsigned getval_276()
{
    return 3677932041U;
}

unsigned addval_465(unsigned x)
{
    return x + 3252717896U;
}

unsigned getval_103()
{
    return 2428610936U;
}

void setval_234(unsigned *p)
{
    *p = 2430634312U;
}

unsigned addval_349(unsigned x)
{
    return x + 3372796553U;
}

unsigned getval_363()
{
    return 3285616970U;
}

unsigned addval_459(unsigned x)
{
    return x + 3682910601U;
}

unsigned addval_353(unsigned x)
{
    return x + 3269495112U;
}

unsigned getval_109()
{
    return 3676357065U;
}

unsigned getval_203()
{
    return 3531915656U;
}

unsigned getval_440()
{
    return 3531129225U;
}

unsigned getval_375()
{
    return 3682912904U;
}

unsigned addval_364(unsigned x)
{
    return x + 3767027731U;
}

unsigned addval_414(unsigned x)
{
    return x + 2425476745U;
}

void setval_245(unsigned *p)
{
    *p = 3353381192U;
}

unsigned getval_423()
{
    return 3378566793U;
}

unsigned addval_421(unsigned x)
{
    return x + 3281049225U;
}

unsigned addval_202(unsigned x)
{
    return x + 3286272840U;
}

void setval_383(unsigned *p)
{
    *p = 3854813837U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
